Ext.define('MyApp.controller.notification.NotificationController', {
    extend: 'Ext.app.Controller',

	requires: [
	    'Ext.Ajax',
	    'Ext.JSON'
	],

	//first method to be called when the app is started
    registerDevice: function() {    	
    	
        var pushNotification = window.plugins.pushNotification;
	    
		//for android device
	    if (device.platform == 'android' || device.platform == 'Android') {
			/*Enter senderID which you get after creating Google API Project in place of 1062386014912*/
			pushNotification.register(MyApp.app.getControllerInstances()['MyApp.controller.notification.NotificationController'].recieveGCMRegistrationId, 
					MyApp.app.getControllerInstances()['MyApp.controller.notification.NotificationController'].errorHandler,
					{"senderID":"1062386014912","ecb":"MyApp.app.getControllerInstances()['MyApp.controller.notification.NotificationController'].onNotificationGCM"});
		} else {	//for other device
			pushNotification.register(MyApp.app.getControllerInstances()['MyApp.controller.notification.NotificationController'].recieveAPNSToken, 
					MyApp.app.getControllerInstances()['MyApp.controller.notification.NotificationController'].errorHandler, 
					{"badge":"true","sound":"true","alert":"true","ecb":"MyApp.app.getControllerInstances()['MyApp.controller.notification.NotificationController'].onNotificationAPN"});
		}
    },
    
    recieveGCMRegistrationId: function(result) {
		MyApp.app.getControllerInstances()['MyApp.controller.notification.NotificationController'].handleRegistrationId(result, 'GCM');
    },
    
    recieveAPNSToken: function(result) {
    	MyApp.app.getControllerInstances()['MyApp.controller.notification.NotificationController'].handleRegistrationId(result, 'APNS');
    },
    
	//this function is called when getting success from registerDevice()
    onNotificationGCM: function(event) {
    	
    	switch( event.event ) {
            case 'registered':	//for device registration
				//alert('Registered, The regid is--->' + event.regid);
            	this.handleRegistrationId(event.regid, 'GCM');
            	break;
            	
            case 'message':	//for receiving notification
				alert('New Transaction Notification');
            	//You Can Perform Some Action here after receiving notification
            	break;
            	
            case 'error':	//for error
            	alert('Error received from GCM Server : ' + error);
            	break;
            
            default:
            	break;
        }
    },
    
    onNotificationAPN: function(event) {
		//something in case of device other than android
    },
    
    errorHandler: function(error) {
		alert('Error in registering device for notifications : ' + error);
    },
    
    handleRegistrationId: function (registrationId, deviceType) { 	
    	
    	if (registrationId.length > 0 ) {
    		
    		var sendToServer = false;    		
			
			var localRegistrationId = window.localStorage.getItem("registrationId");
			
			if(!localRegistrationId || localRegistrationId.length == 0) {
				sendToServer = true; // first time registered;
			}
			else {
				if(localRegistrationId != registrationId) {
					sendToServer = true; // new registrationId received
				}
			}
			
			if (sendToServer) {
				Ext.Ajax.request({
		        	
		            url: MyApp.app.baseURL + "?registration_Id=" + registrationId,	//here you are sending your registrationId of device to server, so that server can send notification to device with the help of registrationId
		    		method: 'POST',
		            
		            headers : {
						'Content-Type' : 'application/json',
					},
		            
		            success: function(response){
						alert('success');
						//save the registration id on local
		            	window.localStorage.setItem("registrationId", registrationId);
		            },
		            error: function(error){
						alert('Error in sending Registration/Token Id to Server : ' + error);
		            }
		        });
			}
		}
	}
});